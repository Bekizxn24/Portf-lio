/* =====================================================
   JAVASCRIPT DO PORTFÓLIO
   Aqui ficam 5 funções:
   1. Ano automático no rodapé
   2. Saudação dinâmica (bom dia / boa tarde / boa noite)
   3. Menu hambúrguer
   4. Modo claro/escuro
   5. Botão de copiar o e-mail
   ===================================================== */


/* ---------- 1. ANO AUTOMÁTICO ----------
   Pega o ano atual do computador e escreve no rodapé.
   Assim não precisa mudar o site todo ano. */
const campoAno = document.getElementById("ano");
campoAno.textContent = new Date().getFullYear();


/* ---------- 2. SAUDAÇÃO DINÂMICA ----------
   Olha a hora atual e escolhe a frase certa. */
const campoSaudacao = document.getElementById("saudacao");
const horaAtual = new Date().getHours();

let saudacao;

if (horaAtual >= 5 && horaAtual < 12) {
  saudacao = "Bom dia! Eu sou";
} else if (horaAtual >= 12 && horaAtual < 18) {
  saudacao = "Boa tarde! Eu sou";
} else {
  saudacao = "Boa noite! Eu sou";
}

campoSaudacao.textContent = saudacao;


/* ---------- 3. MENU HAMBÚRGUER ---------- */
const botaoMenu = document.getElementById("botao-menu");
const menu = document.getElementById("menu");

// Abre ou fecha o menu e avisa os leitores de tela (aria-expanded)
function alternarMenu() {
  const estaAberto = menu.classList.toggle("aberto");

  botaoMenu.setAttribute("aria-expanded", estaAberto);
  botaoMenu.setAttribute("aria-label", estaAberto ? "Fechar menu" : "Abrir menu");
}

// Fecha o menu (usado ao clicar em um link ou apertar Esc)
function fecharMenu() {
  menu.classList.remove("aberto");
  botaoMenu.setAttribute("aria-expanded", "false");
  botaoMenu.setAttribute("aria-label", "Abrir menu");
}

botaoMenu.addEventListener("click", alternarMenu);

// Ao clicar em um link do menu, ele fecha sozinho
const linksDoMenu = menu.querySelectorAll("a");
linksDoMenu.forEach(function (link) {
  link.addEventListener("click", fecharMenu);
});

// Pelo teclado: a tecla Esc fecha o menu e devolve o foco ao botão
document.addEventListener("keydown", function (evento) {
  if (evento.key === "Escape" && menu.classList.contains("aberto")) {
    fecharMenu();
    botaoMenu.focus();
  }
});


/* ---------- 4. MODO CLARO / ESCURO ---------- */
const botaoTema = document.getElementById("botao-tema");
const raiz = document.documentElement; // a tag <html>

// Coloca o tema na página e atualiza o texto do botão
function aplicarTema(tema) {
  raiz.setAttribute("data-theme", tema);

  if (tema === "dark") {
    botaoTema.setAttribute("aria-label", "Mudar para modo claro");
  } else {
    botaoTema.setAttribute("aria-label", "Mudar para modo escuro");
  }
}

// Descobre qual tema usar quando a página abre:
// 1º o que a pessoa escolheu da última vez, 2º a preferência do aparelho
function temaInicial() {
  try {
    const salvo = localStorage.getItem("tema");
    if (salvo === "dark" || salvo === "light") {
      return salvo;
    }
  } catch (erro) {
    // Se o navegador bloquear o armazenamento, seguimos sem salvar
  }

  const aparelhoEscuro = window.matchMedia("(prefers-color-scheme: dark)").matches;
  return aparelhoEscuro ? "dark" : "light";
}

aplicarTema(temaInicial());

// Ao clicar, troca de um tema para o outro e guarda a escolha
botaoTema.addEventListener("click", function () {
  const novoTema = raiz.getAttribute("data-theme") === "dark" ? "light" : "dark";
  aplicarTema(novoTema);

  try {
    localStorage.setItem("tema", novoTema);
  } catch (erro) {
    // Sem armazenamento: o tema só vale até recarregar a página
  }
});


/* ---------- 5. COPIAR O E-MAIL ----------
   Como o site não tem formulário, esse botão facilita o contato. */
const botaoCopiar = document.getElementById("botao-copiar");
const linkEmail = document.getElementById("link-email");
const avisoCopia = document.getElementById("aviso-copia");

botaoCopiar.addEventListener("click", async function () {
  const email = linkEmail.textContent;

  try {
    await navigator.clipboard.writeText(email);
    avisoCopia.textContent = "E-mail copiado!";
  } catch (erro) {
    avisoCopia.textContent = "Não consegui copiar. Selecione o e-mail e copie manualmente.";
  }

  // Apaga a mensagem depois de 3 segundos
  setTimeout(function () {
    avisoCopia.textContent = "";
  }, 3000);
});
